.. ref-dynamodb2

=========
DynamoDB2
=========

boto.dynamodb2
--------------

.. automodule:: boto.dynamodb2
   :members:
   :undoc-members:

boto.dynamodb2.layer1
---------------------

.. automodule:: boto.dynamodb2.layer1
   :members:
   :undoc-members:

boto.dynamodb2.exceptions
-------------------------

.. automodule:: boto.dynamodb2.exceptions
   :members:
   :undoc-members:

Version 20120106
----------------
Upstream release

Version 20111010
----------------
Upstream release

Version 20110725.1
------------------
* Python 3 packaging bug (python3 directory excluded)
* Other packaging bugs (extra files included).


Version 20110725
----------------
Initial PyPI package

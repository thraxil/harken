.. zope.interface documentation master file, created by
   sphinx-quickstart on Mon Mar 26 16:31:31 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to zope.interface's documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2

   README
   adapter
   human
   verify
   foodforthought
   api
   hacking

По-русски
=========

.. toctree::
   :maxdepth: 2

   README.ru
   adapter.ru
   human.ru



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

